// Aside Container
const aside = document.querySelector("aside");


//Array of all the filter options parent div
const filterItems = document.querySelectorAll(".filter-items");

// To Open the filter
const openFilter = () => {
  aside.style.display = aside.style.display === "none" ? "block" : "none";
};

// To toggle the up/down arrow in filter
const handleToggle = (i) => {
  let item = i.nextElementSibling;
  item.style.display = item.style.display === "none" ? "flex" : "none";
};



function formatDateHuman(inputDate) {
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  const formattedDate = new Date(inputDate).toLocaleDateString(undefined, options);
  return formattedDate;
}









// Special filter (Configuration)
const handleConfig = (i) => {
  const items = i.parentElement.querySelectorAll("div");

  if (i.parentElement.dataset.type == "radio") {
    items.forEach((item) => item.classList.remove("active-config"));
    i.classList.add("active-config");
  } else {
    if (i.classList.contains("active-config")) {
      i.classList.remove("active-config");
    } else {
      i.classList.add("active-config");
    }
  }
};

// Adding active class to the clicked element in the see more table
const handleActiveSeeMore = (i) => {
  const elements = i.parentElement.querySelectorAll("p");
  elements.forEach((item) => item.classList.remove("active-see-more"));
  i.classList.toggle("active-see-more");
};



//Open filter in mobile view
const openMobileFilters = () => {
  aside.style.display = aside.style.display === "flex" ? "none" : "flex";
};

// Data of all the filters
const data = {};

const handleSearch = () => {

}

// To Set the searched data in the data object and query backend & get back filtered data

// Clear All the active filters selected
const handleClearAll = () => {

  filterItems.forEach((item) => {
  

    //type = search
    if (item.dataset.type === "search") {
      $(".selectpicker").selectpicker("deselectAll");

      $(".selectpicker").selectpicker("refresh");
    }

    // type = options
    else if (item.dataset.type === "options") {
      let divs = Array.from(item.querySelectorAll("div"));
      divs.map((ele) => {
        if (ele.classList.contains("active-config")) {
          ele.classList.remove("active-config");
        }
      });
    }

    // type = radio
    else if (item.dataset.type === "radio") {
      let divs = Array.from(item.querySelectorAll("div"));
      divs.map((ele) => {
        if (ele.classList.contains("active-config")) {
          ele.classList.remove("active-config");
        }
      });
    }

    // type = daterange
    else if (item.dataset.type === "daterange") {
      item.querySelector("input").value = "";
    }

    // type = range (budget)
    else if (item.dataset.type === "range") {
      const inputs = item.querySelectorAll("input");
      inputs[0].value = "";
      inputs[1].value = "";
    }
  });


// Assuming you have a reference to your select element with an id="search_location"
var selectElement = document.getElementById("search_location");

// Loop through each option and set its selected property to false
for (var i = 0; i < selectElement.options.length; i++) {
  selectElement.options[i].selected = false;
}


// Assuming you have a reference to your select element with an id="search_developer"
var selectElement = document.getElementById("search_developer");

// Loop through each option and set its selected property to false
for (var i = 0; i < selectElement.options.length; i++) {
  selectElement.options[i].selected = false;
}

// Assuming you have a reference to your select element with an id="search_project"
var selectElement = document.getElementById("search_project");

// Loop through each option and set its selected property to false
for (var i = 0; i < selectElement.options.length; i++) {
  selectElement.options[i].selected = false;
}


};




// Add new lead modal accordions handler
const handleDialogAcc = (i) => {
  i.querySelector(".down-arrow").classList.toggle("rotate");
  i.nextElementSibling.style.display =
    i.nextElementSibling.style.display === "block" ? "none" : "block";
};




// Add New Lead Selected Data Object
const addNewLeadData = {};

// All the elements from the add new lead modal
const dialogAllElements = document.querySelectorAll("[data-att]");



//Open the nested options in the table see more quick updates
const openNestedSeeMore = (i) => {
  i.nextElementSibling.style.display =
    i.nextElementSibling.style.display == "none" ? "block" : "none";
};

// Dynamic code to handle all the modals opening & closing
const openDialog = (id) => {
  const modal = document.getElementById(id);
  modal.style.display = "block";
  modal.showModal();
};
const closeDialog = (id) => {
  const modal = document.getElementById(id);
  modal.style.display = "none";
  modal.close();
};

// Not closing the dialog on click of the esc button
const allDialogs = Array.from(document.getElementsByTagName("dialog"));
allDialogs.forEach((item) => {
  item.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
      e.preventDefault();
    }
  });
});


